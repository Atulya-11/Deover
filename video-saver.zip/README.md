# Video Saver

YouTube / Instagram / Facebook ke public video links se download (quality choose karke ya MP3).

## Folder structure
```
app.py
requirements.txt
Dockerfile
templates/index.html
```

## Local test (laptop)
```
pip install -r requirements.txt
# ffmpeg install hona chahiye
python app.py
```
Browser mein `http://localhost:5000` kholo.

## Website par daalna (Render, free tier)
1. Ye folder GitHub repo mein upload karo.
2. render.com par account banao, **New > Web Service** chuno, repo connect karo.
3. Runtime: **Docker** select karo (Dockerfile apne aap detect ho jayega).
4. Deploy dabao. Kuch minute baad tumhara link mil jayega.

## Dhyan rakhne wali baatein
- Netlify/Vercel jaisi static hosting par ye nahi chalega, kyunki backend aur ffmpeg chahiye.
- Instagram/Facebook kabhi kabhi cloud server ke IP ko block karte hain. Aisa ho to kuch videos fail honge.
- `yt-dlp` ko regularly update karo (redeploy karne par latest install hota hai), warna links toot sakte hain.
- Default limit 1 ghante tak ke video. `MAX_DURATION` environment variable se badal sakte ho.
- Sirf public aur permission wale videos ke liye use karo.
